#include<iostream>
using namespace std;
const int MAX = 100;
template<class Type>
class stack
{
	private : Type st[MAX]; 	//	any type of stack of MAX SIZE 	//
		  int top;
	public:
		  stack();			//constructor//
		  void push(Type var); 		//put number on stack
		  Type pop(); 			//take num of stacks
};
//---------------------Defining the Member Function Outside the Class Body-----------------------//
template<class Type>
stack<Type> :: stack() 		//	Same type constructor for all different types	//
{	
	top = -1;	
}
//-----------------------------------------------------------------------------------------------//
template<class Type> 		//	POPING_FUNCTION_BODY_FOR_VARIOUS_TYPES_OF_DATA	//
Type stack<Type> ::pop()
{
	return st[top--];
}
template<class Type>
void stack<Type>::push(Type var)	//		<Type> - for any type......//push()function for various types		//
{
	st[++top]=var;
}
int main()			//	Magic Begins From Here	//
{
	stack<float> s1;	//float data type stack object//
	s1.push(1111.3F);
	s1.push(121.2F);
	s1.push(2031.3F);
	cout<<"3 : "<<s1.pop()<<endl;
	cout<<"2 : "<<s1.pop()<<endl;
	cout<<"1 : "<<s1.pop()<<endl;
	stack<int> s2;			//int data type stack object//
	s1.push(21);
	s1.push(12);
	s1.push(20);
	cout<<"3 : "<<s1.pop()<<endl;
	cout<<"2 : "<<s1.pop()<<endl;
	cout<<"1 : "<<s1.pop()<<endl;
}

