#include<iostream>
using namespace std;
template<class T>
T abs(T n)
{
	return (n<0) ? -n : n;
}
int main()
{
	int i = 5;
	int j = -6;
	long l1 = 70000l;
	long l2 = -80000l;
	double d1 = 9.95;
	double d2 = -10.15;

	cout << "\nabs("<<i<<")="<< abs(i);
	cout << "\nabs("<<j<<")="<< abs(i);
	cout << "\nabs("<<l1<<")="<< abs(l1);
	cout << "\nabs("<<l2<<")="<< abs(l2);
	cout << "\nabs("<<d1<<")="<< abs(d1);
	cout << "\nabs("<<d2<<")="<< abs(d2);
	cout<<endl;
	return 0;
}
