#include<iostream>
using namespace std;
template<class A>
int find(A* arr,A val,int sz)	//	finding the data in the array	//
{
	for(int i=0;i<sz;i++)
		if(arr[i]==val)
			return i;
	return -1;
}
//------------------------------------
char ch_arr[]={1,2,3,4,5,6,8};
char ch = 5;
int int_arr[]={11,22,33,44,55,66,77};
int in = 66;
long lon_arr[] = {1l,3l,5l,4l,7l,6l};
long ln = 4l;
double d_arr[]={1.0,3.0,5.0,7.0,12.0,11.0};
double db = 12.0;
int main()
{
	cout<<"n 5 in chr_Array : index = "<<find(ch_arr,ch,6)<<endl;
	cout<<"n 6 in int_Array : index = "<<find(int_arr,in,66)<<endl;
	cout<<"n 4l in long_Array : index = "<<find(lon_arr,ln,6)<<endl;
	cout<<"n 12.0 in chrArray : index = "<<find(d_arr,db,6)<<endl;
	cout<<endl;
	return 0;
}
